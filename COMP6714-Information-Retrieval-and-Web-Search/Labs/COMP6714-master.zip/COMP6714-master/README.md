# COMP6714 (Information Retrieval and Web Search) @ UNSW

Course web site: http://www.cse.unsw.edu.au/~cs6714/
